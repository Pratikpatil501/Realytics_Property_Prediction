"""
Selenium-based Mumbai Property Scraper (Anti-Bot Resistant)
============================================================
Use this if the requests-based scraper gets blocked by Cloudflare/anti-bot.
Requires: pip install selenium webdriver-manager pandas

Usage:
  python scrape_selenium.py --source both --pages 5 --output scraped_data.csv
"""

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import pandas as pd
import time
import random
import re
import argparse
import os


MUMBAI_REGIONS = [
    "Andheri-East", "Andheri-West", "Bandra-East", "Bandra-West",
    "Borivali-East", "Borivali-West", "Chembur", "Colaba", "Dadar",
    "Dahisar", "Dombivli", "Ghatkopar-East", "Ghatkopar-West",
    "Goregaon-East", "Goregaon-West", "Juhu", "Kalyan",
    "Kandivali-East", "Kandivali-West", "Kanjurmarg", "Khar",
    "Kharghar", "Lower-Parel", "Malad-East", "Malad-West",
    "Mira-Road", "Mulund-West", "Panvel", "Powai", "Thane-West",
    "Ulwe", "Vashi", "Virar", "Wadala", "Worli",
]


def get_driver():
    """Initialize headless Chrome with anti-detection."""
    opts = Options()
    opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    opts.add_argument("--window-size=1920,1080")
    opts.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
    )
    opts.add_experimental_option("excludeSwitches", ["enable-automation"])
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=opts)
    driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
    })
    return driver


def scrape_magicbricks_selenium(driver, region, page=1):
    """Scrape MagicBricks using Selenium."""
    listings = []
    slug = region.lower()
    url = f"https://www.magicbricks.com/property-for-sale/residential-real-estate?bedroom=&proptype=Multistorey-Apartment,Builder-Floor-Apartment,Penthouse,Studio-Apartment,Residential-House,Villa&cityName=Mumbai&page={page}&localityName={slug}"

    try:
        driver.get(url)
        time.sleep(3 + random.uniform(1, 2))

        # Wait for cards
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "[class*='card'], [class*='tuple'], [class*='listing']"))
        )

        cards = driver.find_elements(By.CSS_SELECTOR, "[class*='mb-srp__card'], [class*='SRPCard'], [data-card]")

        for card in cards:
            try:
                text = card.text
                if not text.strip():
                    continue

                bhk = extract_bhk(text)
                price, unit = extract_price(text)
                area = extract_area(text)
                ptype = extract_type(text)
                locality = extract_locality_from_card(card)
                status = "Under Construction" if "under construction" in text.lower() else "Ready to move"
                age = "Resale" if "resale" in text.lower() else "New"

                if bhk and price:
                    listings.append({
                        "bhk": bhk, "type": ptype, "locality": locality,
                        "area": area or 0, "price": price, "price_unit": unit,
                        "region": region.replace("-", " ").title(),
                        "status": status, "age": age,
                    })
            except Exception:
                continue

    except Exception as e:
        print(f"  [MB-Sel] {region} p{page}: {e}")

    return listings


def scrape_99acres_selenium(driver, region, page=1):
    """Scrape 99acres using Selenium."""
    listings = []
    slug = region.lower()
    url = f"https://www.99acres.com/search/property/buy/{slug}-mumbai?city=19&preference=S&area_unit=1&res_com=R&page={page}"

    try:
        driver.get(url)
        time.sleep(3 + random.uniform(1, 2))

        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "[class*='tuple'], [class*='srpTuple'], [class*='card']"))
        )

        cards = driver.find_elements(By.CSS_SELECTOR, "[class*='srpTuple'], [class*='projectTuple'], [class*='srp__card']")

        for card in cards:
            try:
                text = card.text
                if not text.strip():
                    continue

                bhk = extract_bhk(text)
                price, unit = extract_price(text)
                area = extract_area(text)
                ptype = extract_type(text)
                locality = extract_locality_from_card(card)
                status = "Under Construction" if any(k in text.lower() for k in ["under construction", "new launch"]) else "Ready to move"
                age = "Resale" if "resale" in text.lower() else "New"

                if bhk and price:
                    listings.append({
                        "bhk": bhk, "type": ptype, "locality": locality,
                        "area": area or 0, "price": price, "price_unit": unit,
                        "region": region.replace("-", " ").title(),
                        "status": status, "age": age,
                    })
            except Exception:
                continue

    except Exception as e:
        print(f"  [99-Sel] {region} p{page}: {e}")

    return listings


# ─── Extraction helpers ──────────────────────────────────────────────────────────

def extract_bhk(text):
    m = re.search(r'(\d+)\s*(?:BHK|bhk|Bhk|RK|Bedroom|BR)', text, re.I)
    return int(m.group(1)) if m else None

def extract_price(text):
    m = re.search(r'₹?\s*([\d,.]+)\s*(Cr|Crore|L|Lac|Lakh)', text, re.I)
    if m:
        val = float(m.group(1).replace(",", ""))
        raw = m.group(2).lower()
        unit = "Cr" if raw in ("cr", "crore") else "L"
        return val, unit
    return None, None

def extract_area(text):
    m = re.search(r'(\d[\d,]*)\s*(?:sq\.?\s*ft|sqft|sft)', text, re.I)
    if m:
        val = int(m.group(1).replace(",", ""))
        if 100 <= val <= 50000:
            return val
    return None

def extract_type(text):
    t = text.lower()
    if "penthouse" in t: return "Penthouse"
    if "villa" in t: return "Villa"
    if "studio" in t: return "Studio Apartment"
    if "independent" in t or "house" in t: return "Independent House"
    return "Apartment"

def extract_locality_from_card(card):
    try:
        for sel in ["[class*='locName']", "[class*='locality']", "[class*='address']", "[class*='society']", "h2", "h3"]:
            els = card.find_elements(By.CSS_SELECTOR, sel)
            if els:
                txt = els[0].text.strip()
                if txt and len(txt) > 3:
                    return txt[:120]
    except Exception:
        pass
    return ""


def clean_data(df):
    cols = ["bhk", "type", "locality", "area", "price", "price_unit", "region", "status", "age"]
    for c in cols:
        if c not in df.columns:
            df[c] = ""
    df = df[cols].copy()
    df["bhk"] = pd.to_numeric(df["bhk"], errors="coerce")
    df = df[df["bhk"].between(1, 10)]
    df["bhk"] = df["bhk"].astype(int)
    df["area"] = pd.to_numeric(df["area"], errors="coerce").fillna(0).astype(int)
    df["price"] = pd.to_numeric(df["price"], errors="coerce")
    df = df[df["price"] > 0]
    df["price_unit"] = df["price_unit"].replace({"Lac": "L", "Lakh": "L", "Crore": "Cr"})
    df = df[df["price_unit"].isin(["L", "Cr"])]
    valid_types = {"Apartment", "Independent House", "Penthouse", "Studio Apartment", "Villa"}
    df.loc[~df["type"].isin(valid_types), "type"] = "Apartment"
    df.loc[~df["status"].isin(["Ready to move", "Under Construction"]), "status"] = "Ready to move"
    df.loc[~df["age"].isin(["New", "Resale", "Unknown"]), "age"] = "New"
    df = df.drop_duplicates(subset=["bhk", "type", "locality", "area", "price", "region"])
    return df.reset_index(drop=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", default="both", choices=["magicbricks", "99acres", "both"])
    parser.add_argument("--pages", type=int, default=5)
    parser.add_argument("--output", default="scraped_selenium.csv")
    parser.add_argument("--append", default=None)
    args = parser.parse_args()

    print(f"\n🚀 Selenium Scraper — Source: {args.source}, Pages: {args.pages}")
    print(f"   Regions: {len(MUMBAI_REGIONS)}\n")

    driver = get_driver()
    all_listings = []

    try:
        for idx, region in enumerate(MUMBAI_REGIONS, 1):
            print(f"[{idx}/{len(MUMBAI_REGIONS)}] {region}...")

            for page in range(1, args.pages + 1):
                if args.source in ("magicbricks", "both"):
                    mb = scrape_magicbricks_selenium(driver, region, page)
                    all_listings.extend(mb)
                    if mb:
                        print(f"  [MB] p{page}: {len(mb)} listings")

                if args.source in ("99acres", "both"):
                    na = scrape_99acres_selenium(driver, region, page)
                    all_listings.extend(na)
                    if na:
                        print(f"  [99] p{page}: {len(na)} listings")

                time.sleep(random.uniform(2, 4))
    finally:
        driver.quit()

    if not all_listings:
        print("No listings found.")
        return

    df = pd.DataFrame(all_listings)
    df = clean_data(df)
    print(f"\nCleaned: {len(df)} listings")

    if args.append and os.path.exists(args.append):
        existing = pd.read_csv(args.append)
        df = pd.concat([existing, df], ignore_index=True)
        df = df.drop_duplicates(subset=["bhk", "type", "locality", "area", "price", "region"])

    df.to_csv(args.output, index=False)
    print(f"✅ Saved: {args.output} ({len(df)} rows)")


if __name__ == "__main__":
    main()
