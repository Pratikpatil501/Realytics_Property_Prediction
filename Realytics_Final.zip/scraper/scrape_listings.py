"""
Mumbai Property Listing Scraper — MagicBricks & 99acres
=========================================================
Scrapes latest property listings and outputs CSV in the exact format:
  bhk, type, locality, area, price, price_unit, region, status, age

Usage:
  pip install requests beautifulsoup4 pandas
  python scrape_listings.py

Options:
  --source magicbricks|99acres|both   (default: both)
  --pages 10                          (pages per region, default: 5)
  --output scraped_listings.csv
  --append existing.csv               (merge with existing data)
  --delay 2                           (seconds between requests)

Example:
  python scrape_listings.py --source both --pages 8 --output new_data.csv
  python scrape_listings.py --append "Mumbai House Prices.csv" --output merged.csv
"""

import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import random
import re
import argparse
import json
import os
from datetime import datetime

# ─── CONFIG ─────────────────────────────────────────────────────────────────────

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Accept-Language": "en-IN,en;q=0.9",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Referer": "https://www.google.com/",
}

# Mumbai MMR regions to scrape (covers your 228 regions)
MUMBAI_REGIONS = [
    "Andheri-East", "Andheri-West", "Bandra-East", "Bandra-West",
    "Borivali-East", "Borivali-West", "Chembur", "Colaba", "Dadar",
    "Dahisar", "Dombivli", "Fort", "Ghatkopar-East", "Ghatkopar-West",
    "Goregaon-East", "Goregaon-West", "Jogeshwari-East", "Jogeshwari-West",
    "Juhu", "Kalyan", "Kandivali-East", "Kandivali-West", "Kanjurmarg",
    "Khar", "Kharghar", "Lower-Parel", "Malabar-Hill", "Malad-East",
    "Malad-West", "Marine-Lines", "Matunga", "Mira-Road", "Mulund-East",
    "Mulund-West", "Navi-Mumbai", "Nerul", "Panvel", "Parel",
    "Powai", "Prabhadevi", "Santacruz-East", "Santacruz-West", "Sion",
    "Thane-East", "Thane-West", "Ulwe", "Vashi", "Vasai", "Versova",
    "Vikhroli", "Virar", "Wadala", "Worli", "Bhandup", "Churchgate",
    "Dronagiri", "Sewri", "Tardeo", "Kurla", "Airoli", "Belapur",
    "Seawoods", "Kalamboli", "Kamothe", "Badlapur", "Ambernath",
    "Nalasopara", "Bhayandar", "Palava", "Taloja", "Titwala",
    "Karjat", "Khopoli", "Uran", "Ghansoli", "Kopar-Khairane",
]


# ─── MAGICBRICKS SCRAPER ────────────────────────────────────────────────────────

def scrape_magicbricks(region, page=1, session=None):
    """Scrape a single page of MagicBricks listings for a region."""
    listings = []
    slug = region.lower().replace(" ", "-")
    url = f"https://www.magicbricks.com/property-for-sale/residential-real-estate?bedroom=&proptype=Multistorey-Apartment,Builder-Floor-Apartment,Penthouse,Studio-Apartment,Residential-House,Villa&cityName=Mumbai&BudgetMin=&BudgetMax=&page={page}&localityName={slug}"

    try:
        s = session or requests.Session()
        resp = s.get(url, headers=HEADERS, timeout=15)
        if resp.status_code != 200:
            print(f"  [MB] {region} p{page}: HTTP {resp.status_code}")
            return listings

        soup = BeautifulSoup(resp.text, "html.parser")

        # MagicBricks uses JSON-LD structured data
        scripts = soup.find_all("script", type="application/ld+json")
        for script in scripts:
            try:
                data = json.loads(script.string)
                if isinstance(data, list):
                    for item in data:
                        listing = parse_mb_jsonld(item, region)
                        if listing:
                            listings.append(listing)
                elif isinstance(data, dict):
                    listing = parse_mb_jsonld(data, region)
                    if listing:
                        listings.append(listing)
            except (json.JSONDecodeError, TypeError):
                continue

        # Fallback: parse HTML cards
        if not listings:
            cards = soup.select(".mb-srp__card, .mb-srp__list--card, [data-card]")
            for card in cards:
                listing = parse_mb_card(card, region)
                if listing:
                    listings.append(listing)

    except requests.RequestException as e:
        print(f"  [MB] {region} p{page}: Error - {e}")

    return listings


def parse_mb_jsonld(data, region):
    """Parse a JSON-LD listing from MagicBricks."""
    if not isinstance(data, dict):
        return None
    if data.get("@type") not in ("Product", "Apartment", "House", "RealEstateListing", "Residence"):
        return None

    name = data.get("name", "")
    price_raw = None
    if "offers" in data:
        offers = data["offers"]
        if isinstance(offers, dict):
            price_raw = offers.get("price")
        elif isinstance(offers, list) and offers:
            price_raw = offers[0].get("price")

    if not price_raw:
        return None

    price, unit = normalize_price(float(price_raw))
    bhk = extract_bhk(name)
    ptype = extract_type(name, data)
    area = extract_area_from_text(name)
    locality = name.split(" in ")[0].strip() if " in " in name else name[:60]
    clean_region = region.replace("-", " ").title()
    status = "Ready to move"  # default
    age = "New"

    if not bhk or not area:
        return None

    return {
        "bhk": bhk, "type": ptype, "locality": locality,
        "area": area, "price": price, "price_unit": unit,
        "region": clean_region, "status": status, "age": age,
    }


def parse_mb_card(card, region):
    """Parse an HTML card from MagicBricks search results."""
    try:
        # Title / name
        title_el = card.select_one(".mb-srp__card--title, h2, .mb-srp__card--name, [data-title]")
        title = title_el.get_text(strip=True) if title_el else ""

        # Price
        price_el = card.select_one(".mb-srp__card__price--amount, .mb-srp__card--price, [data-price]")
        price_text = price_el.get_text(strip=True) if price_el else ""
        price, unit = parse_price_text(price_text)

        # Area
        area_el = card.select_one(".mb-srp__card__summary--value, [data-area], .mb-srp__card--area")
        area_text = area_el.get_text(strip=True) if area_el else ""
        area = extract_area_from_text(area_text) or extract_area_from_text(title)

        # BHK
        bhk = extract_bhk(title) or extract_bhk(card.get_text())

        # Type
        ptype = extract_type(title, {})

        # Status
        status_el = card.select_one(".mb-srp__card__status, [data-status]")
        status_text = status_el.get_text(strip=True).lower() if status_el else ""
        status = "Under Construction" if "under" in status_text or "construct" in status_text else "Ready to move"

        # Locality
        loc_el = card.select_one(".mb-srp__card--locality, .mb-srp__card__society--name, [data-locality]")
        locality = loc_el.get_text(strip=True) if loc_el else title[:60]

        clean_region = region.replace("-", " ").title()

        if not price or not bhk:
            return None

        return {
            "bhk": bhk, "type": ptype, "locality": locality,
            "area": area or 0, "price": price, "price_unit": unit,
            "region": clean_region, "status": status, "age": "New",
        }
    except Exception:
        return None


# ─── 99ACRES SCRAPER ────────────────────────────────────────────────────────────

def scrape_99acres(region, page=1, session=None):
    """Scrape a single page of 99acres listings for a region."""
    listings = []
    slug = region.lower().replace(" ", "-")
    url = f"https://www.99acres.com/search/property/buy/{slug}-mumbai?city=19&preference=S&area_unit=1&res_com=R&page={page}"

    try:
        s = session or requests.Session()
        resp = s.get(url, headers=HEADERS, timeout=15)
        if resp.status_code != 200:
            print(f"  [99] {region} p{page}: HTTP {resp.status_code}")
            return listings

        soup = BeautifulSoup(resp.text, "html.parser")

        # 99acres also uses JSON-LD
        scripts = soup.find_all("script", type="application/ld+json")
        for script in scripts:
            try:
                data = json.loads(script.string)
                if isinstance(data, list):
                    for item in data:
                        listing = parse_99_jsonld(item, region)
                        if listing:
                            listings.append(listing)
                elif isinstance(data, dict):
                    if "itemListElement" in data:
                        for item in data["itemListElement"]:
                            listing = parse_99_jsonld(item.get("item", item), region)
                            if listing:
                                listings.append(listing)
            except (json.JSONDecodeError, TypeError):
                continue

        # Fallback: HTML parsing
        if not listings:
            cards = soup.select("[class*='srpTuple'], [class*='projectTuple'], .srp__card, [data-listing]")
            for card in cards:
                listing = parse_99_card(card, region)
                if listing:
                    listings.append(listing)

    except requests.RequestException as e:
        print(f"  [99] {region} p{page}: Error - {e}")

    return listings


def parse_99_jsonld(data, region):
    """Parse JSON-LD from 99acres."""
    if not isinstance(data, dict):
        return None

    name = data.get("name", "")
    desc = data.get("description", "")
    combined = f"{name} {desc}"

    price_raw = None
    if "offers" in data:
        offers = data["offers"]
        if isinstance(offers, dict):
            price_raw = offers.get("price") or offers.get("lowPrice")
        elif isinstance(offers, list) and offers:
            price_raw = offers[0].get("price")

    if not price_raw:
        return None

    try:
        price, unit = normalize_price(float(price_raw))
    except (ValueError, TypeError):
        return None

    bhk = extract_bhk(combined)
    ptype = extract_type(combined, data)
    area = extract_area_from_text(combined)
    locality = name[:80] if name else ""
    clean_region = region.replace("-", " ").title()

    status = "Under Construction" if any(k in combined.lower() for k in ["under construct", "new launch", "upcoming"]) else "Ready to move"
    age = "New" if "new" in combined.lower() or status == "Under Construction" else "Resale" if "resale" in combined.lower() else "New"

    if not bhk:
        return None

    return {
        "bhk": bhk, "type": ptype, "locality": locality,
        "area": area or 0, "price": price, "price_unit": unit,
        "region": clean_region, "status": status, "age": age,
    }


def parse_99_card(card, region):
    """Parse HTML card from 99acres."""
    try:
        text = card.get_text(" ", strip=True)

        # Price
        price_match = re.search(r'₹?\s*([\d,.]+)\s*(Cr|L|Lac|Lakh|crore)', text, re.I)
        if not price_match:
            return None
        price, unit = parse_price_text(price_match.group(0))

        bhk = extract_bhk(text)
        ptype = extract_type(text, {})
        area = extract_area_from_text(text)

        loc_el = card.select_one("[class*='locName'], [class*='locality'], [class*='address']")
        locality = loc_el.get_text(strip=True) if loc_el else ""

        status = "Under Construction" if any(k in text.lower() for k in ["under construct", "new launch"]) else "Ready to move"
        age = "Resale" if "resale" in text.lower() else "New"

        clean_region = region.replace("-", " ").title()

        if not price or not bhk:
            return None

        return {
            "bhk": bhk, "type": ptype, "locality": locality or region.replace("-", " "),
            "area": area or 0, "price": price, "price_unit": unit,
            "region": clean_region, "status": status, "age": age,
        }
    except Exception:
        return None


# ─── HELPER FUNCTIONS ────────────────────────────────────────────────────────────

def normalize_price(price_inr):
    """Convert raw INR price to (value, unit) matching your format."""
    if price_inr >= 1_00_00_000:  # 1 Cr+
        return round(price_inr / 1_00_00_000, 2), "Cr"
    elif price_inr >= 1_00_000:  # 1 Lakh+
        return round(price_inr / 1_00_000, 2), "L"
    elif price_inr >= 10_000:  # likely already in lakhs
        return round(price_inr, 2), "L"
    else:
        return round(price_inr, 2), "L"


def parse_price_text(text):
    """Parse price from text like '₹1.23 Cr' or '₹52.5 L'."""
    text = text.replace(",", "").replace("₹", "").strip()
    match = re.search(r'([\d.]+)\s*(Cr|Crore|cr|L|Lac|Lakh|lakh)', text, re.I)
    if match:
        val = float(match.group(1))
        raw_unit = match.group(2).lower()
        unit = "Cr" if raw_unit in ("cr", "crore") else "L"
        return val, unit
    # Try plain number (assume Lakhs if < 500, else Cr)
    plain = re.search(r'([\d.]+)', text)
    if plain:
        val = float(plain.group(1))
        if val > 500:
            return round(val / 100, 2), "Cr"
        return val, "L"
    return None, None


def extract_bhk(text):
    """Extract BHK number from text."""
    match = re.search(r'(\d+)\s*(?:BHK|bhk|Bhk|RK|rk)', text)
    if match:
        return int(match.group(1))
    match = re.search(r'(\d+)\s*(?:Bedroom|bedroom|BR|bed)', text, re.I)
    if match:
        return int(match.group(1))
    return None


def extract_type(text, data):
    """Extract property type from text."""
    t = text.lower()
    if "penthouse" in t:
        return "Penthouse"
    if "villa" in t:
        return "Villa"
    if "studio" in t:
        return "Studio Apartment"
    if "independent" in t or "bungalow" in t or "house" in t:
        return "Independent House"
    return "Apartment"


def extract_area_from_text(text):
    """Extract carpet/built-up area in sq.ft from text."""
    # Try sqft patterns
    patterns = [
        r'(\d[\d,]*(?:\.\d+)?)\s*(?:sq\.?\s*ft|sqft|sft|sq\s*feet)',
        r'carpet\s*(?:area)?\s*:?\s*(\d[\d,]*(?:\.\d+)?)',
        r'built[\s-]*up\s*(?:area)?\s*:?\s*(\d[\d,]*(?:\.\d+)?)',
        r'(\d{3,5})\s*(?:sq|sft|sqft)',
    ]
    for pat in patterns:
        match = re.search(pat, text, re.I)
        if match:
            val = float(match.group(1).replace(",", ""))
            if 100 <= val <= 50000:
                return int(val)

    # Try sqm -> sqft
    sqm_match = re.search(r'(\d[\d,]*(?:\.\d+)?)\s*(?:sq\.?\s*m|sqm|sq\.\s*mtr)', text, re.I)
    if sqm_match:
        val = float(sqm_match.group(1).replace(",", "")) * 10.764
        if 100 <= val <= 50000:
            return int(val)

    return None


def clean_dataframe(df):
    """Clean and validate the scraped data to match your format exactly."""
    # Ensure correct columns
    cols = ["bhk", "type", "locality", "area", "price", "price_unit", "region", "status", "age"]
    for c in cols:
        if c not in df.columns:
            df[c] = ""

    df = df[cols].copy()

    # Clean BHK
    df["bhk"] = pd.to_numeric(df["bhk"], errors="coerce")
    df = df[df["bhk"].between(1, 10)]
    df["bhk"] = df["bhk"].astype(int)

    # Clean area
    df["area"] = pd.to_numeric(df["area"], errors="coerce").fillna(0).astype(int)
    df = df[df["area"] > 0]  # remove listings with no area

    # Clean price
    df["price"] = pd.to_numeric(df["price"], errors="coerce")
    df = df[df["price"] > 0]

    # Ensure valid units
    df["price_unit"] = df["price_unit"].replace({"Lac": "L", "Lakh": "L", "Crore": "Cr"})
    df = df[df["price_unit"].isin(["L", "Cr"])]

    # Clean type
    valid_types = {"Apartment", "Independent House", "Penthouse", "Studio Apartment", "Villa"}
    df.loc[~df["type"].isin(valid_types), "type"] = "Apartment"

    # Clean status
    df.loc[~df["status"].isin(["Ready to move", "Under Construction"]), "status"] = "Ready to move"

    # Clean age
    df.loc[~df["age"].isin(["New", "Resale", "Unknown"]), "age"] = "New"

    # Clean region names (Title Case, no hyphens)
    df["region"] = df["region"].str.replace("-", " ").str.strip().str.title()

    # Truncate locality
    df["locality"] = df["locality"].str[:120]

    # Remove duplicates
    df = df.drop_duplicates(subset=["bhk", "type", "locality", "area", "price", "region"])

    return df.reset_index(drop=True)


# ─── MAIN RUNNER ─────────────────────────────────────────────────────────────────

def run_scraper(source="both", pages_per_region=5, delay=2, output="scraped_listings.csv", append_file=None):
    """Main scraper orchestrator."""
    all_listings = []
    total_regions = len(MUMBAI_REGIONS)
    session = requests.Session()

    print(f"\n{'='*60}")
    print(f"  Mumbai Property Listing Scraper")
    print(f"  Source: {source} | Pages/region: {pages_per_region}")
    print(f"  Regions: {total_regions} | Est. time: ~{total_regions * pages_per_region * delay // 60} min")
    print(f"{'='*60}\n")

    for idx, region in enumerate(MUMBAI_REGIONS, 1):
        print(f"[{idx}/{total_regions}] Scraping {region}...")

        for page in range(1, pages_per_region + 1):
            if source in ("magicbricks", "both"):
                mb = scrape_magicbricks(region, page, session)
                all_listings.extend(mb)
                if mb:
                    print(f"  [MB] page {page}: {len(mb)} listings")
                time.sleep(delay + random.uniform(0.5, 1.5))

            if source in ("99acres", "both"):
                na = scrape_99acres(region, page, session)
                all_listings.extend(na)
                if na:
                    print(f"  [99] page {page}: {len(na)} listings")
                time.sleep(delay + random.uniform(0.5, 1.5))

        # Progress
        if idx % 10 == 0:
            print(f"\n  ── Progress: {idx}/{total_regions} regions, {len(all_listings)} total listings ──\n")

    print(f"\nRaw listings scraped: {len(all_listings)}")

    if not all_listings:
        print("No listings found. Sites may have changed their HTML structure.")
        print("Consider using the Selenium-based alternative (see README).")
        return

    # Build DataFrame
    df = pd.DataFrame(all_listings)
    df = clean_dataframe(df)
    print(f"After cleaning: {len(df)} valid listings")

    # Append to existing data if requested
    if append_file and os.path.exists(append_file):
        existing = pd.read_csv(append_file)
        print(f"Existing data: {len(existing)} rows")
        df = pd.concat([existing, df], ignore_index=True)
        df = df.drop_duplicates(subset=["bhk", "type", "locality", "area", "price", "region"])
        print(f"Merged total: {len(df)} rows (duplicates removed)")

    # Save
    df.to_csv(output, index=False)
    print(f"\n✅ Saved to: {output}")
    print(f"   Rows: {len(df)}")
    print(f"   Columns: {list(df.columns)}")
    print(f"   Regions: {df['region'].nunique()}")
    print(f"   Types: {df['type'].value_counts().to_dict()}")

    # Quick stats
    print(f"\n── Quick Stats ──")
    print(f"   BHK distribution: {df['bhk'].value_counts().sort_index().to_dict()}")
    print(f"   Status: {df['status'].value_counts().to_dict()}")
    print(f"   Price range: ₹{df['price'].min()} - ₹{df['price'].max()} (mixed units)")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Scrape Mumbai property listings")
    parser.add_argument("--source", default="both", choices=["magicbricks", "99acres", "both"])
    parser.add_argument("--pages", type=int, default=5, help="Pages per region (default: 5)")
    parser.add_argument("--output", default="scraped_listings.csv")
    parser.add_argument("--append", default=None, help="Existing CSV to merge with")
    parser.add_argument("--delay", type=float, default=2, help="Delay between requests in seconds")
    args = parser.parse_args()

    run_scraper(
        source=args.source,
        pages_per_region=args.pages,
        delay=args.delay,
        output=args.output,
        append_file=args.append,
    )
