# Mumbai Property Listing Scraper

Scrapes latest property data from **MagicBricks** and **99acres** in the exact CSV format used by your Realytics ML model.

## Output Format (matches your training data)

```
bhk,type,locality,area,price,price_unit,region,status,age
3,Apartment,Lak And Hanware The Residency Tower,685,2.5,Cr,Andheri West,Ready to move,New
2,Apartment,Radheya Sai Enclave,640,52.51,L,Naigaon East,Under Construction,New
```

## Quick Start

### Option 1: Requests + BeautifulSoup (faster, may get blocked)

```bash
pip install requests beautifulsoup4 pandas
python scrape_listings.py --source both --pages 5 --output new_listings.csv
```

### Option 2: Selenium (slower, anti-bot resistant)

```bash
pip install selenium webdriver-manager pandas
python scrape_selenium.py --source both --pages 5 --output new_listings.csv
```

## Usage

```bash
# Scrape both platforms, 5 pages per region
python scrape_listings.py --source both --pages 5 --output scraped.csv

# Scrape only MagicBricks
python scrape_listings.py --source magicbricks --pages 8 --output mb_data.csv

# Scrape and MERGE with your existing training data
python scrape_listings.py --source both --pages 5 --append "Mumbai House Prices.csv" --output merged_data.csv

# Slower delay to avoid rate limiting
python scrape_listings.py --source both --pages 5 --delay 4 --output scraped.csv
```

## After Scraping — Retrain Your Model

```bash
# Merge new data with existing
python -c "
import pandas as pd
old = pd.read_csv('Mumbai House Prices.csv')
new = pd.read_csv('scraped.csv')
merged = pd.concat([old, new]).drop_duplicates(subset=['bhk','type','locality','area','price','region'])
merged.to_csv('Mumbai_House_Prices_Updated.csv', index=False)
print(f'Old: {len(old)}, New: {len(new)}, Merged: {len(merged)}')
"

# Then retrain
python train_model.py
```

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Getting blocked / 403 errors | Use the Selenium scraper instead |
| Very few results | Increase `--pages` to 10-15 |
| Missing area values | Some listings don't show sq.ft; filtered out during cleaning |
| Duplicate regions | Script auto-deduplicates on save |

## Important Notes

- These sites change their HTML structure frequently — if scraping stops working, the CSS selectors may need updating
- Respect rate limits: use `--delay 3` or higher for production runs
- The Selenium version handles JavaScript-rendered content that BS4 can't see
- Run during off-peak hours (late night IST) for better success rates
